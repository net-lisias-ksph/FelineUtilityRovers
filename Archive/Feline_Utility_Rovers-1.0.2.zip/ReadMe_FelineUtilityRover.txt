FELINE UTILITY ROVERS
---------------
	FUR adds parts for Rovers to KSP. Drive them around, have fun.

INSTALLATION
---------------
	To install, simply copy the content of the "GameData" folder into the "GameData" folder of your Kerbal Space Program install.
	When you already have another version of this mod installed, delete it folder first!

CHANGE FILTER
---------------
	You can change if and where filter for this mods are added. This can be done in the "FelineUtilityRover.cfg" file.
    
LICENSING
---------------
	The art assets are licensed under: CC-BY-NC 
        http://creativecommons.org/licenses/by-nc/4.0/
    
    The plugin code is licensed under: Apache License 2.0
        http://www.apache.org/licenses/LICENSE-2.0.html

AUTHOR
---------------
	Nils277
    
CONTRIBUTIONS
---------------
    The hitch system used "Infernal Robotics" from SIRKUT and ZIW as reference implementation.
    The Fuel-Switch is based on the "Firespitter" Fuel-Switch from SNJO