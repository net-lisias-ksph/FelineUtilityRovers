KSP MOD FILE LOCALIZER
---------------
	The KSPModFileLocalizer.0.1.0.dll allows mods to automatically use the correct version of localized static files
    
LICENSING
---------------
	Apache License 2.0
	http://www.apache.org/licenses/LICENSE-2.0.html

AUTHOR
---------------
	Nils277